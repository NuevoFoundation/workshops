/**
 * 🐤🐤🐤
 * Add a function called "jump" and paste
 * 
 * bird.body.velocity.y = -350;
 * 
 * within the function.
 * 
 * Try changing the -350 value! You can make your bird jump really high or really low.
 */
