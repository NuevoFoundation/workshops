function keepBirdInBounds() {
    /**
     *  🐤🐤🐤
     *  Wrap this statement in a conditional that checks that the bird is flying on-screen.
     *  This means that the bird's y/vertical position is between 0 and the screen's height, which is 490 pixels.
     */
}