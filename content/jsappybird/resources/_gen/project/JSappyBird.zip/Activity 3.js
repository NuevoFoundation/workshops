
/*
    First, create an array of pipes. This will allow you to store information about the
    pipes on screen.
*/
var pipes = [];

function checkForCollisions() {
    var bird = mainState.bird;

    /*
        This is a for loop. It looks at every item in your list of pipes.
        This will allow us to check if the bird is colliding with a pipe.

        In activity 1, we added logic that used the bird's y position. We'll have to do something similar
        for each pipe!

        The bird is colliding with the pipe when it hits it from the top or the bottom and 
        the left or the right, which means that we'll need to compare the y positions of the bird and the pipe.
    */
    for (var i = 0; i < pipes.length; i++) {
        if ((pipes[i].y + pipes[i].height) >= bird.y &&
            pipes[i].y < (bird.y + bird.height) &&
            pipes[i].x <= (bird.x + bird.width) &&
            (pipes[i].x + pipes[i].width) > bird.x) {
            mainState.restartGame();
            pipes = [];
        }
    }
}