function addRowOfPipes() {
    /**
     * This code picks a random number between one and five.
     * It'll be used to create a gap for your bird to fly through.
     */
    var hole = Math.floor(Math.random() * 5) + 1;

    /**
     * 🐤🐤🐤
     * We can add the row of pipes by adding a for loop which runs 8 times!
     * Try adding it around the code below!
     */
    addOnePipe(400, i * 60 + 10);
}